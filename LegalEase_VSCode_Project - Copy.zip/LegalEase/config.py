from functools import lru_cache
import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    app_name = os.getenv("APP_NAME", "LegalEase")
    company_name = os.getenv("COMPANY_NAME", "LegalEase")
    gemini_api_key = os.getenv("GEMINI_API_KEY", "").strip()
    gemini_model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
    backend_url = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

@lru_cache
def get_settings():
    return Settings()
