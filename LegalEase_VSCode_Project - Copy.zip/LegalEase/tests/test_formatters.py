from utils.document_formatter import format_docx, format_pdf, format_txt
from utils.text_utils import sanitize_text

def test_sanitize_text():
    assert sanitize_text("“Hello”\r\n\r\n\r\nWorld") == '"Hello"\n\nWorld'

def test_txt_export():
    assert format_txt("Hello LegalEase") == b"Hello LegalEase"

def test_docx_export():
    assert format_docx("1. Introduction\n\nThis is a draft.", "Agreement")[:2] == b"PK"

def test_pdf_export():
    assert format_pdf("1. Introduction\n\nThis is a draft.", "Agreement").startswith(b"%PDF")
