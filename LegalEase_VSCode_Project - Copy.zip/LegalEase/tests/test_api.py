from fastapi.testclient import TestClient
import routes
from main import app

class FakeGenerator:
    def generate_document(self, document_type, parties, terms, effective_date):
        return f"{document_type}\n\nParties: {parties}\nEffective Date: {effective_date}\nTerms: {terms}"

def test_root():
    r = TestClient(app).get("/")
    assert r.status_code == 200
    assert r.json()["status"] == "running"

def test_health():
    r = TestClient(app).get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_generate(monkeypatch):
    monkeypatch.setattr(routes, "GeminiDocumentGenerator", FakeGenerator)
    r = TestClient(app).post("/generate", json={
        "document_type":"NDA","parties":"A and B",
        "terms":"Keep information confidential","effective_date":"2026-09-29"
    })
    assert r.status_code == 200
    assert "confidential" in r.json()["content"].lower()
