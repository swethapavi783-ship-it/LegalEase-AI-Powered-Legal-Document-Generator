from io import BytesIO
import re
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF
from utils.text_utils import sanitize_text

def _lines(text):
    return sanitize_text(text).splitlines()

def format_txt(text):
    return sanitize_text(text).encode("utf-8")

def format_docx(text, doc_type):
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

    normal = document.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(11)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(16)

    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run("LegalEase Draft").italic = True

    for line in _lines(text):
        stripped = line.strip()
        if not stripped:
            document.add_paragraph("")
            continue
        heading = bool(re.match(r"^(\d+[\.\)]\s+|[A-Z][A-Z\s/&-]{4,}:$)", stripped))
        if heading:
            p = document.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(4)
            r = p.add_run(stripped)
            r.bold = True
            r.font.name = "Times New Roman"
            r.font.size = Pt(12)
        elif stripped.startswith(("- ", "* ")):
            document.add_paragraph(stripped[2:], style="List Bullet")
        else:
            p = document.add_paragraph(stripped)
            p.paragraph_format.line_spacing = 1.15

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("Generated with LegalEase - Review before signing").italic = True

    output = BytesIO()
    document.save(output)
    return output.getvalue()

class BrandedPDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.cell(0, 8, "LegalEase", align="C")
        self.ln(10)
    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, "LegalEase - Draft only. Review before signing.", align="C")

def format_pdf(text, doc_type):
    pdf = BrandedPDF()
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(0, 10, sanitize_text(doc_type).upper(), align="C")
    pdf.set_font("Helvetica", "I", 10)
    pdf.multi_cell(0, 7, "LegalEase Draft", align="C")
    pdf.ln(4)

    for line in _lines(text):
        stripped = line.strip()
        if not stripped:
            pdf.ln(3)
            continue
        heading = bool(re.match(r"^(\d+[\.\)]\s+|[A-Z][A-Z\s/&-]{4,}:$)", stripped))
        if heading:
            pdf.set_font("Helvetica", "B", 11)
            pdf.ln(2)
            pdf.multi_cell(0, 6, stripped)
        else:
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(0, 5.5, ("- " + stripped[2:]) if stripped.startswith(("- ", "* ")) else stripped)
    result = pdf.output(dest="S")
    return bytes(result)
