from fastapi import APIRouter, HTTPException
from ai_core.gemini_generator import GeminiDocumentGenerator
from models import DocumentRequest, DocumentResponse

router = APIRouter()

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    try:
        generator = GeminiDocumentGenerator()
        content = generator.generate_document(request.document_type, request.parties, request.terms, request.effective_date)
        return DocumentResponse(document_type=request.document_type, content=content)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI generation failed: {exc}") from exc
