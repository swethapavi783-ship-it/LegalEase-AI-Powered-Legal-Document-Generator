import html
import os
import requests
import streamlit as st
from dotenv import load_dotenv
from utils.document_formatter import format_docx, format_pdf, format_txt
from utils.text_utils import sanitize_text

load_dotenv()
st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

def preview_html(text):
    escaped = html.escape(sanitize_text(text))
    blocks = [f"<p>{p.replace(chr(10), '<br>')}</p>" for p in escaped.split("\n\n")]
    return f'''<div style="background:#111827;color:#f9fafb;border-radius:14px;padding:24px;max-height:600px;overflow-y:auto;line-height:1.65;border:1px solid #374151;">{"".join(blocks)}</div>'''

left, center, right = st.columns([1,2,1])
with center:
    st.image("assets/logo.svg", width=110)
    st.markdown('<h1 style="text-align:center">LegalEase</h1>', unsafe_allow_html=True)
    st.markdown('<p style="text-align:center;color:#6b7280">AI-Powered Legal Document Generator</p>', unsafe_allow_html=True)

st.info("LegalEase creates general-purpose drafts. It does not provide legal advice or guarantee local legal compliance.")

with st.form("document_form"):
    c1, c2 = st.columns(2)
    with c1:
        document_type = st.text_input("Document Type", "Non-Disclosure Agreement")
        parties = st.text_area("Parties Involved", placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)", height=120)
    with c2:
        effective_date = st.text_input("Effective Date", placeholder="September 29, 2026")
        terms = st.text_area("Terms & Conditions", placeholder="Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice", height=120)
    submitted = st.form_submit_button("✨ Generate Document", type="primary", use_container_width=True)

if submitted:
    if not all([document_type.strip(), parties.strip(), terms.strip(), effective_date.strip()]):
        st.error("Please complete all fields before generating.")
    else:
        try:
            with st.spinner("Generating your legal-document draft..."):
                r = requests.post(f"{BACKEND_URL}/generate", json={
                    "document_type": document_type.strip(),
                    "parties": parties.strip(),
                    "terms": terms.strip(),
                    "effective_date": effective_date.strip(),
                }, timeout=120)
            if r.ok:
                data = r.json()
                st.session_state["document_type"] = data["document_type"]
                st.session_state["content"] = data["content"]
                st.session_state["edited"] = False
                st.success("Document generated successfully.")
            else:
                try: detail = r.json().get("detail", r.text)
                except Exception: detail = r.text
                st.error(f"Backend error: {detail}")
        except requests.RequestException as exc:
            st.error("Could not connect to FastAPI. Start it with: uvicorn main:app --reload --port 8000")
            st.caption(str(exc))

if "content" in st.session_state:
    st.divider()
    st.subheader("Document Preview")
    if not st.session_state.get("edited", False):
        st.markdown(preview_html(st.session_state["content"]), unsafe_allow_html=True)
    if st.button("✏️ Edit Document"):
        st.session_state["edited"] = True
    if st.session_state.get("edited", False):
        edited = st.text_area("Edit generated document", st.session_state["content"], height=600)
        if st.button("Save Edits", type="primary"):
            st.session_state["content"] = edited
            st.session_state["edited"] = False
            st.rerun()
        st.markdown(preview_html(edited), unsafe_allow_html=True)

    content = st.session_state["content"]
    doc_type = st.session_state["document_type"]
    st.subheader("Download")
    d1, d2, d3 = st.columns(3)
    with d1:
        st.download_button("⬇️ Download TXT", format_txt(content), "legalease_document.txt", "text/plain", use_container_width=True)
    with d2:
        st.download_button("⬇️ Download DOCX", format_docx(content, doc_type), "legalease_document.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
    with d3:
        st.download_button("⬇️ Download PDF", format_pdf(content, doc_type), "legalease_document.pdf", "application/pdf", use_container_width=True)

st.divider()
st.caption("LegalEase • AI-assisted drafting • Review documents before signing")
