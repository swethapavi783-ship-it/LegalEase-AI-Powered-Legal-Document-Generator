import requests
r = requests.get("http://127.0.0.1:8000/health", timeout=5)
r.raise_for_status()
print(r.json())
