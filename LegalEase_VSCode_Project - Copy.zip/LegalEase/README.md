# LegalEase — AI-Powered Legal Document Generator

Complete runnable project based on the supplied LegalEase documentation.

## Stack
- Streamlit frontend
- FastAPI backend
- Google GenAI SDK / Gemini
- python-docx DOCX export
- fpdf2 PDF export
- TXT export
- Editable preview
- Tests and VS Code launch/tasks

> LegalEase creates general-purpose drafts. It is not a substitute for qualified legal advice and does not guarantee legal validity in any jurisdiction.

## VS Code setup

Open this folder in VS Code.

### Windows PowerShell
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

If activation is blocked:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\.venv\Scripts\Activate.ps1
```

### Configure Gemini
Edit `.env`:
```env
GEMINI_API_KEY=your_real_api_key_here
GEMINI_MODEL=gemini-2.5-flash
BACKEND_URL=http://127.0.0.1:8000
```

### Run backend
```bash
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```
Open `http://127.0.0.1:8000/docs`.

### Run frontend
In a second terminal:
```bash
streamlit run app.py
```
Open the URL shown by Streamlit, normally `http://localhost:8501`.

### Test
```bash
pytest -q
```

## Usage
1. Enter document type.
2. Enter parties.
3. Enter semicolon-separated terms.
4. Enter effective date.
5. Generate.
6. Edit if needed.
7. Download TXT, DOCX or PDF.

## API
POST `/generate`:
```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Jane Doe (Disclosing Party), TechNova Inc. (Receiving Party)",
  "terms": "Confidentiality must be maintained; Information may be used only for evaluation",
  "effective_date": "2026-09-29"
}
```

## Deployment
The included Dockerfile runs FastAPI. The Procfile is suitable for platforms supporting a web process. For production, add authentication, rate limiting, secret management, audit/privacy controls, and jurisdiction-specific legal review.
