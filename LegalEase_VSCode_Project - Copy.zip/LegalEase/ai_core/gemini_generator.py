from google import genai
from google.genai import types
from config import get_settings

class GeminiDocumentGenerator:
    SYSTEM_INSTRUCTION = '''
You are LegalEase, an assistant that drafts general-purpose legal-document
templates from user-provided facts.

Rules:
- Produce a professional, editable document draft.
- Do not invent party identities, addresses, amounts, dates, or obligations.
- Use placeholders such as [INSERT DETAILS] when important information is missing.
- Organize the document with a clear title, numbered sections, and clauses.
- Reflect the user's supplied terms accurately.
- Use neutral legal drafting language.
- Do not claim that the document is legally valid in a specific jurisdiction.
- End with a short Review Notice stating that the draft should be reviewed by
  an appropriately qualified legal professional before signing.
- Return plain text only.
'''

    def __init__(self):
        self.settings = get_settings()
        if not self.settings.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured. Add it to your .env file.")
        self.client = genai.Client(api_key=self.settings.gemini_api_key)

    def generate_document(self, document_type, parties, terms, effective_date):
        clauses = [x.strip() for x in terms.split(";") if x.strip()]
        terms_block = "\n".join(f"- {x}" for x in clauses)
        prompt = f'''
Create a {document_type} draft.

PARTIES:
{parties}

EFFECTIVE DATE:
{effective_date}

USER-SUPPLIED TERMS:
{terms_block}

Required structure:
1. Title
2. Parties and Effective Date
3. Purpose / Background
4. Definitions where useful
5. Main obligations and rights
6. Relevant clauses such as confidentiality, intellectual property, payment,
   termination, only when appropriate to the document type and supplied facts
7. Governing law as a placeholder if no jurisdiction was supplied
8. Signatures

Preserve all material facts supplied by the user.
'''
        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=self.SYSTEM_INSTRUCTION,
                temperature=0.25,
                max_output_tokens=5000,
            ),
        )
        text = (response.text or "").strip()
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text
